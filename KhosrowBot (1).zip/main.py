# خسرو: بات تلگرامی هوشمند با مغزهای قابل ارتقا
print('Khosrow is running...')